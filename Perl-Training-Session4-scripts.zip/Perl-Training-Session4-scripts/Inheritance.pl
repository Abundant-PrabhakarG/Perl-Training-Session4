use strict;
use warnings;

use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use btech;

my $a = btech->new("Sam",01);

print "Student Name: $a->{'name'}\n";
print "Roll Number:  $a->{'roll_number'}\n";