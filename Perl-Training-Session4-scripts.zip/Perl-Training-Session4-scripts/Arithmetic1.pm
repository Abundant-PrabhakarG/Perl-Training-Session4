package Arithmetic1;
use strict;

use Exporter;
our @ISA="Exporter";
our @EXPORT = qw(add);
our @EXPORT = qw(subtract);

sub add 
{ 
my $a=$_[0]; 
my $b=$_[1]; 
return ($a+$b); 
}

sub subtract 
{ 
my $a=$_[0]; 
my $b=$_[1]; 
return ($a-$b); 
} 
1;
