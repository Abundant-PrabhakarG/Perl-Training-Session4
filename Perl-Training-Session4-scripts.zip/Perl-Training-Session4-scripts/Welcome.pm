package Welcome;

use strict;
our $var1 = 1;
my $var2 = 3;

my $str = "Welcome\n";

sub greet {
   return $str;
}
1;
