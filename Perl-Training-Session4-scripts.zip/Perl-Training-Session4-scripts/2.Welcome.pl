use strict;
use warnings;

use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use Welcome;

my $var1 =$Welcome::var1;
my $var2 =$Welcome::var2;

print "Our variable scope: $var1\n";
print "My variable scope:  $var2\n";

print Welcome::greet();
