use strict;
use warnings;
 
use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use Arithmetic;

my $obj= Arithmetic->new(); 

my $result= $obj->add(5,6); 
print "Addition: $result\n";

$result = $obj->subtract(6,5);
print "Subtraction: $result\n";