package Hello; 

sub greet { 
   print "Hello World\n";
} 
1;
