use strict;
use warnings;

use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use HI qw(greet);
use HI;

print greet();
print "\n";
print greet2();
print greet3();
print greet4();
