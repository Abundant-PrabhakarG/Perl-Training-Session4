package HI;
use strict;

use Exporter;
our @ISA="Exporter";
our @EXPORT_OK = qw(greet);
our @EXPORT = qw(greet2 greet3 greet4);


my $str = "Hello World!";
sub greet {
   return $str;
}

my $str1 = "HI! This is greet2\n";
sub greet2 {
   return $str1;
}


my $str2 = "HI! This is greet3\n";
sub greet3 {
   return $str2;
}

my $str3 = "HI! This is greet4\n";
sub greet4 {
   return $str3;
}
1;
