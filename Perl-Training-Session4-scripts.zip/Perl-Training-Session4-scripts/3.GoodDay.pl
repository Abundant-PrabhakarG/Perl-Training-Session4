use strict;
use warnings;
 
use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use GoodDay qw(greet);

print "var1= $GoodDay::var1\n";
print "var2= $GoodDay::var2\n";

print greet();
