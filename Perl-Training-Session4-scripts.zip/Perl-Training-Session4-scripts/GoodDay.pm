package GoodDay;
use strict;

require Exporter;
our @ISA="Exporter";
our @EXPORT_OK = qw(greet);

our $var1 = 1;
our $var2 = 3;

my $str = "GoodDay!\n";

sub greet {
   return $str;
}
1;
