use strict;
use warnings;
 
use lib 'C:/Users/Local User/Documents/Perl-Training/Perl-Training-Session4-scripts/';
use Arithmetic1;

my $result= Arithmetic1::add(5,6); 
print "Addition: $result\n";

$result = Arithmetic1::subtract(6,5);
print "Subtraction: $result\n";