use strict;
use warnings;

package student;

sub new{

  my $class = shift;

  my $self = {
    'name' => shift,
    'roll_number' => shift
  };

  bless $self, $class;

  return $self;
}

1;